﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        public TimeSpan HoraEgreso
        {
            get { return horaEgreso; }
            set 
            { 
                TimeSpan egresoAux = ValidarHoraEgreso(value);
                {
                    horaEgreso = egresoAux;
                }
            }
        }

        public TimeSpan HoraIngreso {get { return horaIngreso; } }

        public string Legajo { get { return legajo; } }

        public string Nombre { get { return nombre; } }
        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaEgreso = horaIngreso;
        }

        public abstract string EmitirFactura();


        protected virtual double Facturar()
        {
            double horasFacturadas = HoraEgreso.TotalHours - HoraIngreso.TotalHours;
            return horasFacturadas;
        }

        public static bool operator ==(Empleado emp1, Empleado emp2)
        {
            if (emp1.Legajo == emp2.Legajo)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(Empleado emp1, Empleado emp2)
        {
            return !(emp1 == emp2);
        }

        private TimeSpan ValidarHoraEgreso(TimeSpan horaEgreso)
        {
            if (horaEgreso > HoraIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }
    }
}
