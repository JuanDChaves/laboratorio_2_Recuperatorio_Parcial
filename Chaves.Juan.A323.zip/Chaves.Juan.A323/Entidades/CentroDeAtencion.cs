﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class CentroDeAtencion
    {
        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public List<Empleado> Empleados { get { return empleados; } } 
        public string Nombre { get {  return nombre; } }

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;   
            this.cantRacsPorSuper = cantRacsPorSuper;
            empleados = new List<Empleado>();
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Empleado emp in empleados)
            {
                sb.AppendLine($"{emp.Nombre}");
            }
            return "";
        }

        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            if(c.empleados.Contains(e)) {
                return true;
            }
            return false;
          
        }
        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !(c == e);
        }
        public static bool operator +(CentroDeAtencion c, Empleado e)
        {
            if(c == e)
            {
                c.empleados.Add(e);
                return true;
            }
            return false;
        }
        public static string operator -(CentroDeAtencion c, Empleado e)
        {
            if (c != e)
            {
                return "Empleado no encontrado";
            }
            else
            {
                e.HoraEgreso = DateTime.Now.TimeOfDay;
                return e.EmitirFactura();
                //empleados.Remove(e);
            }
        }
        private bool ValidaCantidadDeRacs()
        {
            if(empleados.Count > 0)
            {
                return true;
            }
            return false;
        }
    }
}
