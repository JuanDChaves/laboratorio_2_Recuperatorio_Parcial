﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Entidades
{
    public class Supervisor : Empleado
    {
        private static float valorHora;

        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (valorHora > 0)
                {
                    valorHora = value;
                }
            }
        }

        static Supervisor()
        {
            valorHora = 1025.50F;
        }

        private Supervisor(string legajo)
        {
            this.legajo = legajo;
            this.nombre = "N/A";
            this.horaIngreso = new TimeSpan(09, 00, 00);
        }

        private Supervisor(string legajo, string nombre, TimeSpan horaIngreso) :base (legajo, nombre, horaIngreso)
        {
        }
        public override string EmitirFactura()
        {
            double facturacion = Facturar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Factura de: {this.ToString()}\nImporte a facturar: {facturacion.ToString()}");
            return sb.ToString();
        }

        protected override double Facturar()
        {
            double horasFacturadas = HoraEgreso.TotalHours - HoraIngreso.TotalHours;
            double facturacion = horasFacturadas * ValorHora;

            return facturacion;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {legajo} - {nombre}";
        }

        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo);
        }
    }
}
