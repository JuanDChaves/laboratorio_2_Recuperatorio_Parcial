﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum EGrupo
    {
        CALL_IN,
        CALL_OUT,
        RRSS
    }
    public class Rac : Empleado
    {
        private EGrupo grupo = EGrupo.CALL_IN;
        static double valorHora;

        public EGrupo Grupo { get { return grupo; } }
        public static double ValorHora 
        { 
            get {  return valorHora; }
            set 
            {  
                if (valorHora > 0) 
                {
                    valorHora = value;
                }
            }
        }

        private double CalcularBonoDeGrupo()
        {
            if (this.grupo == EGrupo.CALL_IN)
            {
                return 0.0;
            } else if (this.grupo == EGrupo.CALL_OUT)
            {
                return 0.1;
            } else
            {
                return 0.2;
            }     
        }

        public override string EmitirFactura()
        {
            double facturacion = Facturar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Factura de: {this.ToString()}\nImporte a facturar: {facturacion.ToString()}");
            return sb.ToString();
        }
        protected override double Facturar()
        {
            double bono = CalcularBonoDeGrupo();
            double horasFacturadas = HoraEgreso.TotalHours - HoraIngreso.TotalHours;
            double facturacion = horasFacturadas * ValorHora;
            double facturacionConBono = facturacion + (horasFacturadas * bono);

            return facturacionConBono;
        }

        static Rac()
        {
            valorHora = 875.90F;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso) :base (legajo, nombre, horaIngreso)
        {
        }
        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo egrupo) :this (legajo, nombre, horaIngreso)
        {
            this.grupo = egrupo;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {grupo} - { legajo}- { nombre}";
        }
    }

}
